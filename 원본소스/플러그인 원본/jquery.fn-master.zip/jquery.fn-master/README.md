jquery.fn
===

*A collection of jQuery plugins*

**Note**: This is an old repo. These plugins are not being actively developed, and they're
mostly small and simple enough for anyone familiar with JS/jQuery/DOM to understand.
If something's broken, I recommend looking into the code. It's nice to know how stuff
works anyway... 

###Containing:

 * [Pulse][2]
 * [Macro][3]
 * [Cross domain Ajax][4]
 * [sortElements][5]
 * [Proximity event][6]
 
 
###Licenses

As of 2013 these plugins are released to the public domain under [UNLICENSE](http://unlicense.org/UNLICENSE).
 
[2]: http://github.com/padolsey/jQuery-Plugins/tree/master/pulse/
[3]: http://github.com/padolsey/jQuery-Plugins/tree/master/macro/
[4]: http://github.com/padolsey/jQuery-Plugins/tree/master/cross-domain-ajax/
[5]: http://github.com/padolsey/jQuery-Plugins/tree/master/sortElements/
[6]: http://github.com/padolsey/jQuery-Plugins/tree/master/proximity-event/
