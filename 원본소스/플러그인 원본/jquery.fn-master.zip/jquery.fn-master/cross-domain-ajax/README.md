Cross domain mod for jQuery
---

This small mod for jQuery enables you to make GET requests, accross domains! You can use jQuery's Ajax methods as you usually would.

It uses [YQL][1]. [Read more here][2]!

[1]: http://developer.yahoo.com/yql/
[2]: http://james.padolsey.com/javascript/cross-domain-requests-with-jquery/